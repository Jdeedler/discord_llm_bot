"""
Main entry point for the Discord LLM Bot.
"""
from src.bot import main

if __name__ == "__main__":
    main()
